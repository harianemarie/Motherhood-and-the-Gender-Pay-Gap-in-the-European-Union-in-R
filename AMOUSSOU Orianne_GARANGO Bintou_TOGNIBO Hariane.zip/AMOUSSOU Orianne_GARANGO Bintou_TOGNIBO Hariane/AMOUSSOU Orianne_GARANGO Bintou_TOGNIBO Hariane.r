# Installation des packages
library(tidyverse)
library(readr)
library(dplyr)
library(readxl)
library(ggplot2)
library(patchwork)
library(tidyr)
library(gt)
library(webshot2)
library(plm)
library(modelsummary)
library(lmtest)
library(sandwich)
library(car)
library(gridExtra)
library(grid)

# View the working directory
getwd()
# Change my working directory
setwd("C:/Users/haria/OneDrive/Documents/Base de données MPE/data/raw")

# Data importation

# La variable dépendante écart salariale notée "ecart_sal"
ecart_sal <- read_csv("earn_gr_gpgr2__custom_20233590_linear_2_0.csv")

# La variable explicative et les variables de contrôle : part des femmes cadre, taux de fécondité, 
# pourcentage d'adultes en emploi à temps partiel par nombre d'enfants et âge du plus jeune enfant, taux d'emploi 
# féminin notées respectivement "femmes_cadres", "taux_fec", "adult_emploi", "emploi_fem".

taux_fec <- read_csv("demo_frate__custom_20329085_linear_2_0.csv")
femmes_cadres <- read_csv("sdg_05_60__custom_20318970_linear_2_0.csv")
adult_emploi <- read_csv("lfst_hhptechi__custom_20319045_linear_2_0.csv")
emploi_fem <- read_csv("lfsi_emp_a__custom_20319015_linear_2_0.csv")

# Vérification de la structure des données
glimpse(ecart_sal)
glimpse(femmes_cadres)
glimpse(taux_fec)
glimpse(adult_emploi)
glimpse(emploi_fem)

# Nettoyage des bases

# *Au niveau de la variable part des femmes cadres, nous avons deux différentes positions professionnelles : BRD et 
# EXEC, après analyse de nos données, nous constatons que nous avons beaucoup de valeurs manquantes au niveau de 
# la position professionnelle EXEC donc nous chisons de garder uniquement BRD car selon la logique, une femme 
# faisant partie du conseil d'administration peut déjà être dirigeante.

years <- 2010:2023

complete_countries <- femmes_cadres %>%
  filter(TIME_PERIOD %in% years) %>%
  group_by(geo) %>%
  summarise(n_years = n_distinct(TIME_PERIOD), .groups = "drop") %>%
  filter(n_years == length(years)) %>%
  pull(geo)

print(complete_countries)

# appliquer le filtre
femmes_cadres <- femmes_cadres %>%
  filter(geo %in% complete_countries,
         TIME_PERIOD %in% years,
         prof_pos == "BRD") %>%
  group_by(geo, TIME_PERIOD) %>%
  summarise(part_femmes_brd = mean(OBS_VALUE, na.rm = TRUE), .groups = "drop")

# Passons au nettoyage de la variable écart salariale
# Nous avons plusieurs variantes pour l’activité économique nace_r2. Il faut décider comment traiter ces multiples 
# activités avant d’agréger par pays×année pour obtenir une seule valeur d’écart salarial par pays et par année.)

# Voir modalités et effectifs
ecart_sal %>%
  count(nace_r2, sort = TRUE) %>%
  print(n = 100)

# Repérer pays×année avec >1 observation (pour comprendre la multiplicité)
ecart_sal %>%
  group_by(geo, TIME_PERIOD) %>%
  tally(name = "n_obs") %>%
  filter(n_obs > 1) %>%
  arrange(desc(n_obs)) %>%
  print(n = 50)

# On va construire un indicateur en faisant la moyenne simple agrégée par pays et année des différents secteurs
ecart_sal <- ecart_sal %>%
  group_by(geo, TIME_PERIOD) %>%
  summarise(ecart_salarial = mean(OBS_VALUE, na.rm = TRUE), n_sources = n(), .groups = "drop")

# Identifier automatiquement les pays présents dans la base
pays_auto <- sort(unique(ecart_sal$geo))

# Construire la grille complète pays × années
ecart_sal <- expand_grid(geo = pays_auto, TIME_PERIOD = years) %>%
  left_join(ecart_sal, by = c("geo", "TIME_PERIOD")) %>%
  arrange(geo, TIME_PERIOD)

#*Pour la variable taux d'emploi on garde uniquement pour les femmes ayant 3 enfants ou plus 
adult_emploi <- adult_emploi %>%
  filter(n_child == "GE3") %>%
  group_by(geo, TIME_PERIOD) %>%
  summarise(
    emploi_tp_GE3 = mean(OBS_VALUE, na.rm = TRUE),
    n_sources = n(),
    .groups = "drop")

# Compléter la grille automatiquement
adult_emploi <- expand_grid(geo = pays_auto, TIME_PERIOD = years) %>%
  left_join(adult_emploi, by = c("geo", "TIME_PERIOD")) %>%
  arrange(geo, TIME_PERIOD)


  # Variable ecart salariale
ecart_sal <- ecart_sal %>%
  select(geo, TIME_PERIOD, ecart_salarial) %>%
  rename(
    pays = geo,
    annee = TIME_PERIOD)

  # La variable dépendante et les variables de contrôle
taux_fec <- taux_fec %>%
  select(geo, TIME_PERIOD, OBS_VALUE) %>%
  rename(
    pays = geo,
    annee = TIME_PERIOD,
    taux_fecondite = OBS_VALUE)

femmes_cadres <- femmes_cadres %>%
  select(geo, TIME_PERIOD, part_femmes_brd) %>%
  rename(
    pays = geo,
    annee = TIME_PERIOD,
    femmes_cadres = part_femmes_brd)

emploi_fem <- emploi_fem %>%
  select(geo, TIME_PERIOD, OBS_VALUE) %>%
  rename(
    pays = geo,
    annee = TIME_PERIOD,
    emploi_feminin = OBS_VALUE)

adult_emploi <- adult_emploi %>%
  select(geo, TIME_PERIOD, emploi_tp_GE3) %>%
  rename(
    pays = geo,
    annee = TIME_PERIOD,
    adult_emploi = emploi_tp_GE3)

# Sauvegardons les différentes bases obtenues
setwd("C:/Users/haria/OneDrive/Documents/Base de données MPE/")
write.csv(ecart_sal, file = "data/out/ecart_sal.csv")
write.csv(taux_fec, file = "data/out/taux_fec.csv")
write.csv(femmes_cadres, file = "data/out/femmes_cadres.csv")
write.csv(emploi_fem, file = "data/out/emploi_fem.csv")
write.csv(adult_emploi, file = "data/out/adult_emploi.csv")

# Fusion des différentes bases en une seule 
final_base <- ecart_sal %>%
  full_join(taux_fec, by = c("pays", "annee")) %>%
  full_join(femmes_cadres, by = c("pays", "annee")) %>%
  full_join(emploi_fem, by = c("pays", "annee")) %>%
  full_join(adult_emploi, by = c("pays", "annee"))

# Convertir les NaN en NA afin d’assurer une gestion homogène des données manquantes 
final_base[] <- lapply(final_base, function(x) {
  x[is.nan(x)] <- NA
  x
})

sapply(final_base, function(x) sum(is.nan(x)))
sapply(final_base, function(x) sum(is.na(x)))

write.csv(final_base, file = "data/out/final_base.csv")

# Statistique descriptive
glimpse(final_base)
summary(final_base)

# Tableau de statistique descriptive
base_num <- final_base[, !(names(final_base) %in% c("pays", "annee"))]

tab <- base_num %>%
  summarise(across(
    everything(),
    list(
      Mean = ~mean(.x, na.rm = TRUE),
      SD = ~sd(.x, na.rm = TRUE),
      Min = ~min(.x, na.rm = TRUE),
      Max = ~max(.x, na.rm = TRUE)
    )
  )) %>%
  pivot_longer(
    everything(),
    names_to = c("Variable", ".value"),
    names_pattern = "(.*)_(Mean|SD|Min|Max)"
  ) %>%
  mutate(across(where(is.numeric), round, 2))

tab

tab_png <- gt(tab) %>%
  tab_header(title = "Tableau de statistiques descriptives") %>%
  tab_source_note(source_note = "Source : Eurostat, sortie R")

gtsave(tab_png, "tables/tableau_statistiques.png")

# Diagramme de densité de la distribution de l'écart salarial
final_base %>%
  filter(!is.na(ecart_salarial)) %>%
  ggplot(aes(x = ecart_salarial)) +
  
  geom_histogram(aes(y = after_stat(density)), bins = 30, fill = "orange", alpha = 0.85, 
                 color = "white") +
  geom_density(color = "darkred", size = 1) +
  theme_minimal(base_size = 14) +
  labs(
    title = "Distribution de l'écart salarial",
    x = "Écart salarial (%)",
    y = "Densité",
    caption = "Source : Eurostat, Sortie R") +
  theme(
    panel.grid.major = element_line(color = "grey85"),
    panel.grid.minor = element_line(color = "grey90"),
    plot.caption = element_text(hjust = 0, size = 10, face = "italic"),
    plot.title = element_text(size = 12, face = "bold"))
ggsave("figs/densite_ecart_salarial.png", width = 10, height = 6, dpi = 300)


# Evolution de l'écart salariale par année
  # Calcul de la moyenne UE par année
ecart_ue <- final_base %>%
  group_by(annee) %>%
  summarise(mean_ecart = mean(ecart_salarial, na.rm = TRUE))

# Moyenne de l'écart salariale en fonction de l'année
ggplot(ecart_ue, aes(x = annee, y = mean_ecart)) +
  geom_line(color = "#2f4b7c", linewidth = 1.8) +       
  geom_point(color = "#2f4b7c", size = 3) +              
  scale_x_continuous(breaks = seq(min(ecart_ue$annee), max(ecart_ue$annee), by = 2)) +
  labs(
    title = "Évolution moyenne de l’écart salarial dans l’UE",
    x = "Année",
    y = "Écart salarial moyen (%)",
    caption = "Source : Eurostat, Sortie R") +
  theme_minimal(base_size = 15) +
  theme(
    panel.grid.major = element_line(color = "grey85", linewidth = 0.4),
    panel.grid.minor = element_blank(),
    plot.background = element_rect(fill = "white", color = NA),
    plot.title = element_text(face = "bold", size = 18),
    axis.title = element_text(face = "bold"))
ggsave("figs/moyenne_ecart_salarial_annee.png", width = 10, height = 6, dpi = 300)

# Evolution de l'écart salarial en fonction des pays 
# Sélection de 4 pays : France, Allemagne, Espagne, Suède
pays_selection <- c("FR", "DE", "ES", "SE")

base_4pays <- final_base %>%
  filter(pays %in% pays_selection)

ggplot(base_4pays, aes(x = annee, y = ecart_salarial, color = pays, group = pays)) +
  geom_line(linewidth = 1.4, alpha = 0.9) +
  geom_point(size = 3, alpha = 0.9) +
  scale_x_continuous(
    breaks = seq(min(base_4pays$annee), max(base_4pays$annee), by = 2)
  ) +
  scale_color_viridis_d(option = "turbo") +
  labs(
    title = "Évolution de l’écart salarial pour quatre pays de l’UE",
    x = "Année",
    y = "Écart salarial (%)",
    color = "Pays"
  ) +
  theme_minimal(base_size = 15) +
  theme(
    plot.title = element_text(face = "plain", size = 18),
    axis.title = element_text(face = "plain"),
    panel.grid.major = element_line(color = "grey85", linewidth = 0.4),
    panel.grid.minor = element_blank(),
    plot.background = element_rect(fill = "white", color = NA),
    legend.position = "bottom",
    legend.title = element_text(face = "plain"),
    legend.text = element_text(size = 11))
ggsave("figs/evolution_ecart_salarial_pays.png", width = 10, height = 6, dpi = 300)

# Calculons des moyennes annuelles
df_evo <- final_base %>%
  group_by(annee) %>%
  summarise(
    fecondite_moy = mean(taux_fecondite, na.rm = TRUE),
    cadres_moy = mean(femmes_cadres, na.rm = TRUE),
    emploi_fem_moy = mean(emploi_feminin, na.rm = TRUE),
    emploi_adult_moy = mean(adult_emploi, na.rm = TRUE)
  )

# Axe des abscisses 
axe_x <- scale_x_continuous(
  breaks = seq(min(df_evo$annee), max(df_evo$annee), by = 1)
)

g1 <- ggplot(df_evo, aes(annee, fecondite_moy)) +
  geom_line(color = "#2C3E50", size = 1.2) +
  theme_minimal(base_size = 13) +
  labs(title = "Évolution du taux de fécondité", x = "Année", y = "Moyenne") +
  axe_x +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

g2 <- ggplot(df_evo, aes(annee, cadres_moy)) +
  geom_line(color = "#C2185B", size = 1.2) +
  theme_minimal(base_size = 13) +
  labs(title = "Évolution de la proportion de femmes cadres", x = "Année", y = "Moyenne (%)") +
  axe_x +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

g3 <- ggplot(df_evo, aes(annee, emploi_fem_moy)) +
  geom_line(color = "#1ABC9C", size = 1.2) +
  theme_minimal(base_size = 13) +
  labs(title = "Évolution de l'emploi féminin", x = "Année", y = "Moyenne (%)") +
  axe_x +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

g4 <- ggplot(df_evo, aes(annee, emploi_adult_moy)) +
  geom_line(color = "#9B59B6", size = 1.2) +
  theme_minimal(base_size = 13) +
  labs(title = "Évolution de l'emploi adulte", x = "Année", y = "Moyenne (%)") +
  axe_x +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

(g1 | g2) /
  (g3 | g4) +
  plot_annotation(
    caption = "Source : Eurostat, Sortie R",
    theme = theme(
      plot.caption = element_text(
        hjust = 0.5,
        size = 10,
        face = "italic",
        margin = margin(t = 15)
      )
    )
  )

ggsave("graphiques.png", width = 10, height = 6, dpi = 300)

# Traitons les valeurs manquantes avant la régression
# Pourcentage de valeurs manquantes par variable et par pays
sapply(final_base, function(x) mean(is.na(x)) * 100)

final_base %>%
  group_by(pays) %>%
  summarise(pct_na = mean(is.na(ecart_salarial)) * 100) %>%
  arrange(desc(pct_na))

# Supprimons les colonnes incomplètes 
final_base <- final_base %>%
  drop_na(ecart_salarial, taux_fecondite, femmes_cadres, emploi_feminin, adult_emploi)

# Estimation du modèle linéaire multiple 
# Verification entre X et Y

install.packages("kableExtra")
webshot2::install_phantomjs()

modele_simple <- plm(ecart_salarial ~ taux_fecondite,
                        data = final_base,
                        index = c("pays", "annee"),
                        model = "within",
                        effect = "individual")

summary(modele_simple)

ggplot(final_base, aes(x = taux_fecondite, y = ecart_salarial)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm", se = TRUE, color = "blue") +
  theme_minimal() +
  labs(title = "Relation brute entre taux de fécondité et écart salarial",
      x = "Taux de fécondité",
      y = "Écart salarial")

ggsave("figs/regression_simple.png", width = 10, height = 6, dpi = 300)

# Modèle à effets fixes 
modele <- plm(ecart_salarial ~ taux_fecondite + femmes_cadres + emploi_feminin + adult_emploi,
                 data = final_base,
                 index = c("pays", "annee"),
                 model = "within")

summary(modele)

# Création et export en PNG
modelsummary(modele,
  statistic = "({std.error})",
  stars = TRUE,
  gof_omit = "IC|Log|F|RMSE",
  add_rows = data.frame(
    term = "Source",
    estimate = "Eurostat, sortie RStudio"),
  title = "Modèle de régression à effets fixes : déterminants de l'écart salarial",
  output = "regression_FE.png")

# Extraire les résidus des effets fixes
# On crée les variables "nettoyées" des effets fixes pays
df_fe <- final_base %>%
  group_by(pays) %>%
  mutate(
    Y_fe = ecart_salarial - mean(ecart_salarial, na.rm = TRUE),
    X_fe = taux_fecondite - mean(taux_fecondite, na.rm = TRUE)
  ) %>%
  ungroup()

ggplot(df_fe, aes(x = X_fe, y = Y_fe)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm", se = TRUE, color = "red") +
  theme_minimal() +
  labs(
    title = "Relation entre Y et X après retrait des effets fixes pays",
    x = "Taux de fécondité",
    y = "Écart salarial",
    caption = "Source : Eurostat, Sortie R")

ggsave("figs/regression_fe.png", width = 10, height = 6, dpi = 300)

# ============================
#   TESTS DE VALIDATION 
# ============================

  # Multicolinéarité
modele_ols <- lm(ecart_salarial ~ taux_fecondite + femmes_cadres + emploi_feminin + adult_emploi, 
                 data = final_base) 
vif_table <- data.frame( variable = names(vif(modele_ols)), 
                         VIF = as.numeric(vif(modele_ols)) ) 
print(vif_table)

  # Testons la normalité des résidus
residus_fe <- residuals(modele)

qqnorm(residus_fe,
       main = "QQ-plot des résidus (normalité)")
qqline(residus_fe, col = "red", lwd = 2)

    # Test de Shapiro-Wilk (attention : sensible aux grands échantillons)
shapiro_test <- shapiro.test(residus_fe)
print(shapiro_test)

  # Testons l'homoscédasticité 
    # Test de Breusch-Pagan :
bp_test <- bptest(modele)
print(bp_test)

  # Testons d'autocorrélation (Wooldridge)
wooldridge_test <- pwartest(modele)
print(wooldridge_test)

  # Test de dépendance entre unités (Pesaran CD)
pesaran_test <- pcdtest(modele, test = "cd")
print(pesaran_test)


# Enregistrement en png
modele_ols <- lm(ecart_salarial ~ taux_fecondite + femmes_cadres + emploi_feminin + adult_emploi, 
                 data = final_base)

modele_panel <- plm(ecart_salarial ~ taux_fecondite + femmes_cadres + emploi_feminin + adult_emploi,
                    data = final_base,
                    index = c("pays", "annee"),
                    model = "within")  

# ===== 1. VIF =====
vif_table <- data.frame(
  Variable = names(vif(modele_ols)),
  VIF = as.numeric(vif(modele_ols))
)

tab_vif <- tableGrob(vif_table, rows = NULL)

# ===== 2. NORMALITÉ =====
residus <- residuals(modele_ols)

shapiro_test <- shapiro.test(residus)

tab_shapiro <- tableGrob(
  data.frame(
    Test = "Shapiro-Wilk",
    Statistique = round(shapiro_test$statistic, 4),
    p_value = round(shapiro_test$p.value, 4)
  ),
  rows = NULL
)

# ===== 3. HÉTÉROSCÉDASTICITÉ =====
bp_test <- bptest(modele_ols)

tab_bp <- tableGrob(
  data.frame(
    Test = "Breusch-Pagan",
    Statistique = round(bp_test$statistic, 4),
    p_value = round(bp_test$p.value, 4)
  ),
  rows = NULL
)

# ===== 4. AUTOCORRÉLATION =====
wooldridge_test <- pwartest(modele_panel)

tab_wooldridge <- tableGrob(
  data.frame(
    Test = "Wooldridge",
    Statistique = round(wooldridge_test$statistic, 4),
    p_value = round(wooldridge_test$p.value, 4)
  ),
  rows = NULL
)

# ===== 5. DÉPENDANCE ENTRE UNITÉS =====
pesaran_test <- pcdtest(modele_panel, test = "cd")

tab_pesaran <- tableGrob(
  data.frame(
    Test = "Pesaran CD",
    Statistique = round(pesaran_test$statistic, 4),
    p_value = round(pesaran_test$p.value, 4)
  ),
  rows = NULL
)

# ===== EXPORT IMAGE =====
png("tests_econometriques.png", width = 1000, height = 1200)

grid.arrange(
  textGrob("Résultats des tests économétriques",
           gp = gpar(fontsize = 18, fontface = "bold")),
  
  textGrob("Test de multicolinéarité (VIF)", gp = gpar(fontsize = 14)),
  tab_vif,
  
  textGrob("Test de normalité des résidus", gp = gpar(fontsize = 14)),
  tab_shapiro,
  
  textGrob("Test d'hétéroscédasticité", gp = gpar(fontsize = 14)),
  tab_bp,
  
  textGrob("Test d'autocorrélation", gp = gpar(fontsize = 14)),
  tab_wooldridge,
  
  textGrob("Test de dépendance entre unités", gp = gpar(fontsize = 14)),
  tab_pesaran,

  ncol = 1,
  heights = c(0.2, 0.1, 1, 0.1, 1, 0.1, 1, 0.1, 1, 0.1, 1))
dev.off()


# Introduisons les erreurs standards robustes clusterisées
coeftest(modele, vcov = vcovHC(modele, type = "HC1", cluster = "group"))

modelsummary(modele,
             statistic = "({std.error})",
             stars = TRUE,
             vcov = vcov_cluster,
             gof_omit = "IC|Log|F|RMSE",
             add_rows = data.frame(
               term = "Source",
               estimate = "Eurostat, sortie RStudio"),
             title = "Modèle de régression avec erreurs standards robustes",
             output = "regression_robuste.png")